import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import { useNavigate } from 'react-router-dom';
import zeducimg from '../assets/logo (2).png';



const Signadmin = () => {

    const navigate = useNavigate();

    const VersSign = () => {
     navigate('/accueil');
    }
  
    return (
        <div className="login-container d-flex align-items-center justify-content-center vh-100">
            <div className="login-card card p-4">
                {/* Première div : Image */}
                <div className="text-center mb-4 ">
                    <img 
                        src={zeducimg } 
                        alt="Logo" 
                        className="login-logo bg-black rounded-circle"
                    />
                </div>

                {/* Deuxième div : Champs de formulaire */}
                
                <div>
                    <p>Se connecter en tant que qui? </p>
                    <select
                        className="form-select my-3"
                    >
                        <option value="left">Gérant</option>
                        <option value="right">Employé</option>
                        <option value="right">Administrateur </option>
                    </select>
                </div>
                
                
                {/* Deuxième div : Champs de formulaire */}
                <div className="mb-3">
                    <input 
                        type="email" 
                        className="form-control mb-3" 
                        placeholder="Email" 
                    />
                    <input 
                        type="password" 
                        className="form-control" 
                        placeholder="Mot de passe" 
                    />
                </div>

                {/* Bouton de connexion */}
                <div className='my-2'>
                    <a to="/acceuil" className="btn btn-primary w-100" onClick={VersSign }>
                        se connecter
                    </a>
                </div>

            </div>
        </div>
    );
};

export default Signadmin;
