import React, { useState, useEffect } from 'react';
import Navbar from './NavigaAdmin';
import Address from '../Panier_Etudiant/Address';

const Employe = () => {
  const [employees, setEmployees] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  // Charger les employés depuis la base de données
  useEffect(() => {
    fetch('http://localhost/backend/Employe.php')
      .then(response => {
        if (!response.ok) {
          throw new Error('Erreur lors de la récupération des employés');
        }
        return response.json();
      })
      .then(data => {
        console.log('Employés récupérés:', data);
        setEmployees(data); // Le backend renvoie déjà les employés actifs
      })
      .catch(error => console.error('Erreur de chargement:', error));
  }, []);

  const handleDeactivate = (employeeEmail) => {
    if (window.confirm("Êtes-vous sûr de vouloir supprimer cet employé ?")) {
      fetch(`http://localhost/backend/EmployeSupprimer.php?email=${employeeEmail}`, {
        method: 'DELETE', // Utiliser DELETE pour désactiver l'employé
        headers: { 'Content-Type': 'application/json' }
      })
      .then(response => {
        if (response.ok) {
          setEmployees(prevEmployees => prevEmployees.filter(emp => emp.email !== employeeEmail));
        } else {
          throw new Error('Erreur lors de la désactivation');
        }
      })
      .catch(error => console.error('Erreur de requête:', error));
    }
  };
  
  

  const handleAddEmployee = () => {
    const newEmployee = { email, password, statut: 1 };
    
    fetch('http://localhost/backend/Employe.php', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(newEmployee)
    })
    .then(response => {
      if (response.ok) {
        return response.json();
      } else {
        throw new Error('Erreur d\'ajout');
      }
    })
    .then(data => {
      console.log(data.message); // Afficher le message de succès
      setEmployees(prev => [...prev, newEmployee]); // Ajouter à la liste des employés
      setShowModal(false);
      setEmail('');
      setPassword('');
    })
    .catch(error => console.error('Erreur de requête:', error));
  };
  
  return (
    <div className="container">
      <Navbar />
      <div className="d-flex justify-content-between align-items-center my-4">
        <h1 className="imprint-text text-white" style={{ fontFamily: 'Imprint MT Shadow' }}>Vos Employés</h1>
        <input
          type="text"
          className="form-control w-25"
          placeholder="Rechercher..."
        />
      </div>

      <button className="btn btn-primary mb-3" onClick={() => setShowModal(true)}>
        Ajouter un employé
      </button>

      <table className="table table-bordered">
        <thead>
          <tr>
            <th scope="col" style={{ fontFamily: 'Imprint MT Shadow' }}>Email</th>
            <th scope="col" style={{ fontFamily: 'Imprint MT Shadow' }}>Action</th>
          </tr>
        </thead>
        <tbody>
          {employees.map((employee) => (
            <tr key={employee.email}>
              <td>{employee.email}</td>
              <td className='d-flex justify-center space-between'>
                <button className="btn border" onClick={() => handleDeactivate(employee.email)} style={{ fontFamily: 'Imprint MT Shadow' }}>Supprimer </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* Modal pour ajouter un employé */}
      {showModal && (
        <div className="modal show" style={{ display: 'block' }}>
          <div className="modal-dialog modal-lg" style={{ maxWidth: '800px' }}>
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">Ajouter un employé</h5>
                <button type="button" className="close" onClick={() => setShowModal(false)}>
                  &times;
                </button>
              </div>
              <div className="modal-body">
                <div className="mb-3">
                  <label htmlFor="employeeEmail" className="form-label">Email</label>
                  <input 
                    type="email" 
                    className="form-control" 
                    id="employeeEmail" 
                    value={email} 
                    onChange={(e) => setEmail(e.target.value)} 
                  />
                </div>
                <div className="mb-3">
                  <label htmlFor="employeePassword" className="form-label">Mot de passe</label>
                  <input 
                    type="password" 
                    className="form-control" 
                    id="employeePassword" 
                    value={password} 
                    onChange={(e) => setPassword(e.target.value)} 
                  />
                </div>
              </div>
              <div className="modal-footer">
                <button type="button" className="btn btn-secondary" onClick={() => setShowModal(false)}>Fermer</button>
                <button type="button" className="btn btn-primary" onClick={handleAddEmployee}>Ajouter l'employé</button>
              </div>
            </div>
          </div>
        </div>
      )}

      <Address />
    </div>
  );
};

export default Employe;
