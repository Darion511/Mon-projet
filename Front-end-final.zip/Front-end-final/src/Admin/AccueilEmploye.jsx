import React from 'react'

const AcceuilEmploye = () => {
  return (
    <div>AcceuilEmploye</div>
  )
}

export default AcceuilEmploye