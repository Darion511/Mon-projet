import Home1 from "./Home1";
import NavigatorA from "./NavigatorA";
import Hero from "./Hero";
import Main from "./Main";
import Main1 from "./Main1";
import Address from "../Panier_Etudiant/Address";



const Home = () => {
  return (
    <>
      <NavigatorA/>
      <Hero/>
      <Main/>
      <Main1/>
      <Main/>
      <Home1  />
      <Address />
    </>
  );
};
  
export default Home;
    