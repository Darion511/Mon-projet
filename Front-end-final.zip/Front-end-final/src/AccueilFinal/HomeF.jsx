import Home1 from "../Accueil/Home1";
import NavigatorF from "./NavigatorF";
import Hero from "../Accueil/Hero";
import Main from "../Accueil/Main";
import Main1 from "../Accueil/Main1";
import Address from "../Panier_Etudiant/Address";



const HomeF = () => {
  return (
    <>
      <NavigatorF/>
      <Hero/>
      <Main/>
      <Main1/>
      <Main/>
      <Home1  />
      <Address />
    </>
  );
};
  
export default HomeF;