import React from 'react'
import NavGerant from './NavGerant'

export const Gerant = () => {
  return (
    <div>
      <NavGerant/>
    </div>
  )
}
export default Gerant;
