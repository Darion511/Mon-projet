import React from 'react'

export const CommandesGerant = () => {
  return (
    <div>CommandesGerant</div>
  )
}
