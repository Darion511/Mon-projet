
import TitreE from "./TitreE"; 
import Address from "../Panier_Etudiant/Address";
import NavigatorF from "../AccueilFinal/NavigatorF";
import Even from "./Even";
function Final(){
    return(
      <>
        <NavigatorF/>
        <TitreE/>
        <Even/>
        <Address/>
      </>  
    );
}

export default Final;