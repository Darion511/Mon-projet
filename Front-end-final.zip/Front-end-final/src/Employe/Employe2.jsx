import React from 'react'
import NavEmploye from './NavEmploye'

const Employe2 = () => {
  return (
    <div>
        <NavEmploye/>
        Employe
    </div>
  )
}

export default Employe2