function Title(){
    return (
        <>
            <div className="container-fluid ">
                <h1 className="text-center text-white d-flex mt-5"style={{fontFamily:'Imprint MT Shadow'}}>Votre Panier</h1>
                <div className="bg-white">
                <hr/>
                </div>
            </div>
        </>
    );
}

export default Title;